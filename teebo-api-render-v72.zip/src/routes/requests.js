import express from 'express';
import { q, tx } from '../db.js';
import { notifyWhatsApp, notifyEmail, TEEBO_WHATSAPP, TEEBO_EMAIL, verifyDocToken } from '../notify.js';
import { getBranding, renderInvoice, moneyFcfa, setDocumentCsp } from '../documents.js';
import {
  computePricing, buildInvoiceLines, normalizeModules, catalogModule,
  BILLING_CYCLES, LICENCE_CENTS, TRIAL_BILLING_NOTE, MODULE_KEYS, MODULE_CATALOG
} from '../pricing.js';

const router = express.Router();

// Pays UEMOA + indicatifs (le front affiche l'indicatif selon le pays choisi)
export const UEMOA = [
  { code: 'BJ', name: 'Bénin',          dial: '+229' },
  { code: 'BF', name: 'Burkina Faso',   dial: '+226' },
  { code: 'CI', name: "Côte d'Ivoire",  dial: '+225' },
  { code: 'GW', name: 'Guinée-Bissau',  dial: '+245' },
  { code: 'ML', name: 'Mali',           dial: '+223' },
  { code: 'NE', name: 'Niger',          dial: '+227' },
  { code: 'SN', name: 'Sénégal',        dial: '+221' },
  { code: 'TG', name: 'Togo',           dial: '+228' }
];
const UEMOA_CODES = UEMOA.map(c => c.code);

router.get('/uemoa-countries', (_req, res) => res.json({ countries: UEMOA }));

// ---------------------------------------------------------------------------
// AUTO-RÉPARATION du schéma requis pour le dépôt d'une demande d'accès.
// Le RCCM / IFU (mentions légales de facturation) et les colonnes de suivi de
// la demande proviennent de migrations successives. Si l'une d'elles n'a pas
// été jouée sur la base de production, l'INSERT échouait et l'API renvoyait
// « server_error » — donc « Une erreur est survenue » côté formulaire, sans
// aucune explication. On sécurise donc ces objets de façon idempotente avant
// d'écrire, exactement comme le fait déjà l'onglet Organisation.
let _requestSchemaEnsured = false;
async function ensureRequestSchema() {
  if (_requestSchemaEnsured) return;
  await q(`
    CREATE TABLE IF NOT EXISTS imf_branding (
      imf_id UUID PRIMARY KEY REFERENCES imf(id) ON DELETE CASCADE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
    ALTER TABLE imf_branding ADD COLUMN IF NOT EXISTS legal_name          TEXT;
    ALTER TABLE imf_branding ADD COLUMN IF NOT EXISTS legal_form          TEXT;
    ALTER TABLE imf_branding ADD COLUMN IF NOT EXISTS trade_register_no   TEXT;
    ALTER TABLE imf_branding ADD COLUMN IF NOT EXISTS tax_id              TEXT;
    ALTER TABLE imf_branding ADD COLUMN IF NOT EXISTS bceao_agreement_no  TEXT;
    ALTER TABLE imf_branding ADD COLUMN IF NOT EXISTS share_capital_cents BIGINT;
    ALTER TABLE imf_branding ADD COLUMN IF NOT EXISTS legal_address       TEXT;

    CREATE TABLE IF NOT EXISTS access_request (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      imf_id UUID NOT NULL REFERENCES imf(id) ON DELETE CASCADE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
    ALTER TABLE access_request ADD COLUMN IF NOT EXISTS requester_lastname  TEXT;
    ALTER TABLE access_request ADD COLUMN IF NOT EXISTS requester_firstname TEXT;
    ALTER TABLE access_request ADD COLUMN IF NOT EXISTS requester_position  TEXT;
    ALTER TABLE access_request ADD COLUMN IF NOT EXISTS admin_name          TEXT;
    ALTER TABLE access_request ADD COLUMN IF NOT EXISTS billing_cycle       TEXT;
    ALTER TABLE access_request ADD COLUMN IF NOT EXISTS licence_cents       BIGINT;
    ALTER TABLE access_request ADD COLUMN IF NOT EXISTS subscription_cents  BIGINT;
    ALTER TABLE access_request ADD COLUMN IF NOT EXISTS discount_cents      BIGINT DEFAULT 0;
    ALTER TABLE access_request ADD COLUMN IF NOT EXISTS decision            TEXT;
    ALTER TABLE access_request ADD COLUMN IF NOT EXISTS plan_code            TEXT;
    ALTER TABLE access_request ADD COLUMN IF NOT EXISTS proforma_no          TEXT;
    ALTER TABLE access_request ADD COLUMN IF NOT EXISTS proforma_amount_cents BIGINT;
    ALTER TABLE access_request ADD COLUMN IF NOT EXISTS proforma_validated    BOOLEAN NOT NULL DEFAULT false;
    ALTER TABLE access_request ADD COLUMN IF NOT EXISTS proforma_validated_at TIMESTAMPTZ;
    ALTER TABLE access_request ADD COLUMN IF NOT EXISTS decided_by            UUID;
    ALTER TABLE access_request ADD COLUMN IF NOT EXISTS decided_at            TIMESTAMPTZ;
    ALTER TABLE access_request ADD COLUMN IF NOT EXISTS module_codes          TEXT[] NOT NULL DEFAULT '{}'::text[];
    ALTER TABLE access_request ADD COLUMN IF NOT EXISTS module_count          INTEGER NOT NULL DEFAULT 0;
    ALTER TABLE access_request ADD COLUMN IF NOT EXISTS full_pack             BOOLEAN NOT NULL DEFAULT false;
    ALTER TABLE access_request ADD COLUMN IF NOT EXISTS pack_discount_cents   BIGINT NOT NULL DEFAULT 0;
    ALTER TABLE access_request ADD COLUMN IF NOT EXISTS annual_discount_cents BIGINT NOT NULL DEFAULT 0;
  `);
  _requestSchemaEnsured = true;
}

// ---------------------------------------------------------------------------
// CATALOGUE DES MODULES (abonnement par module)
// ---------------------------------------------------------------------------
// Le prospect ne choisit plus une « formule » : il coche les MODULES dont il a
// besoin. Cet appel renvoie le catalogue officiel + les règles de facturation
// (licence unique, cycle mensuel/annuel, remise pack complet, essai par module).
// La composition du prix est recalculée côté serveur au moment de la proforma :
// un prix bricolé dans le navigateur n'a donc aucun effet.
router.get('/plans', async (req, res, next) => {
  try {
    // CORRECTIF 52 : si la table des tarifs n'existe pas encore (migration
    // partielle), on NE renvoie PLUS une erreur 500 : le catalogue du code
    // (pricing.js) est la reference et suffit a afficher la grille.
    let rows = [];
    try {
      ({ rows } = await q(
        `SELECT p.module_key AS code, p.module_name AS label,
                p.monthly_subscription_price::bigint AS price_cents,
                p.is_available, p.position AS sort_order
           FROM saas_modules_pricing p
          ORDER BY p.position, p.module_key`));
    } catch (e) {
      console.error('[plans] table de tarifs indisponible, catalogue du code utilise :', e && (e.code || e.message));
      rows = [];
    }
    if (!rows.length) {
      // Catalogue de secours : libelles, prix et descriptions viennent du code.
      rows = MODULE_CATALOG.map((m) => ({
        code: m.key, label: m.label,
        price_cents: m.monthlyCents, is_available: true,
        sort_order: MODULE_CATALOG.indexOf(m) * 10 + 10
      }));
    }
    const catalogue = rows.map((r) => ({
      code: r.code,
      label: r.label,
      price_cents: Math.round(Number(r.price_cents) || 0),
      monthly_cents: Math.round(Number(r.price_cents) || 0),
      description: (catalogModule(r.code) || {}).description || null,
      short: (catalogModule(r.code) || {}).short || null,
      is_available: r.is_available !== false
    }));
    const availables = catalogue.filter((m) => m.is_available);
    const fullPackCents = availables.reduce((s, m) => s + m.monthly_cents, 0);
    res.json({
      modules: catalogue,
      plans: catalogue,                       // alias historique des écrans
      billing_cycles: BILLING_CYCLES,
      licence_cents: LICENCE_CENTS,
      licence_once: true,
      annual_discount_percent: 15,
      full_pack_discount_percent: 5,
      full_pack_monthly_cents: fullPackCents,
      trial_days_per_module: 30,
      pricing_model: 'par_module'
    });
  } catch (e) { next(e); }
});

/** Liste de modules reçue du navigateur (codes ou objets). */
function requestedModules(b) {
  const raw = b && (b.module_codes || b.modules || b.module_keys || b.plan_codes);
  if (!Array.isArray(raw)) return [];
  const codes = raw.map((x) => (typeof x === 'string' ? x : (x && (x.code || x.key || x.module_key)))).filter(Boolean);
  // On ne garde que les modules du catalogue officiel, sans doublon, dans
  // l'ordre du catalogue (facture toujours présentée dans le même ordre).
  const seen = new Set();
  return MODULE_KEYS.filter((k) => codes.includes(k)).filter((k) => {
    if (seen.has(k)) return false;
    seen.add(k);
    return true;
  });
}

function validEmail(e) { return /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e || ''); }

// --- Étape 1 : dépôt du formulaire IMF ------------------------------------
router.post('/', async (req, res, next) => {
  try {
    const b = req.body || {};
    const required = ['lastname','firstname','position','country_code','imf_type',
      'capital_cents','bceao_agreement_no','rccm','ifu','whatsapp','phone_main','city','email','admin_name','imf_name'];
    // On renvoie TOUS les champs manquants (et pas seulement le premier) : le
    // formulaire peut ainsi les signaler d'un coup au lieu d'obliger l'utilisateur
    // à renvoyer autant de fois qu'il manque de champs.
    const missing = required.filter(f => b[f] === undefined || b[f] === null || b[f] === '');
    if (missing.length)
      return res.status(422).json({ error: 'missing_field', field: missing[0], missing,
        message: 'Certaines informations obligatoires sont manquantes. Complétez-les puis renvoyez le formulaire.' });
    if (!UEMOA_CODES.includes(b.country_code))
      return res.status(422).json({ error: 'country_not_uemoa', field: 'country_code',
        message: 'Le pays de l’institution doit appartenir à l’UEMOA.' });
    if (!['SA','SCOOP'].includes(b.imf_type))
      return res.status(422).json({ error: 'invalid_imf_type', field: 'imf_type',
        message: 'Choisissez la forme juridique de l’institution (SA ou SCOOP).' });
    if (!validEmail(b.email))
      return res.status(422).json({ error: 'invalid_email', field: 'email',
        message: 'L’adresse e-mail saisie n’est pas valide.' });

    // Le schéma n'est réparé qu'APRÈS la validation : un formulaire incomplet ne
    // doit jamais dépendre d'un accès à la base pour afficher son message. Si la
    // réparation échoue, on continue : les colonnes existent déjà en production,
    // et l'insertion signalera elle-même la cause exacte si ce n'est pas le cas.
    try { await ensureRequestSchema(); }
    catch (err) { console.error('[requests] ensureRequestSchema:', err && err.message); }

    // --- Anti-doublon : une seule demande d'accès par IMF -------------------
    // On refuse une 2e demande pour la même IMF, identifiée par son numéro
    // d'agrément BCEAO OU par l'e-mail déjà enregistré. Une demande précédemment
    // REJETÉE n'empêche pas de retenter (decision = 'rejected' exclue).
    const dup = await q(
      `SELECT i.code_imf
         FROM imf i
         JOIN access_request ar ON ar.imf_id = i.id
        WHERE (lower(i.email) = lower($1) OR i.bceao_agreement_no = $2)
          AND (ar.decision IS DISTINCT FROM 'rejected')
        LIMIT 1`,
      [b.email, b.bceao_agreement_no]);
    if (dup.rows.length)
      return res.status(409).json({ error: 'duplicate_request',
        message: 'Une demande d’accès existe déjà pour cette IMF (numéro d’agrément BCEAO ou e-mail déjà enregistré). Contactez teeBo si vous pensez qu’il s’agit d’une erreur.' });

    const out = await tx(async (c) => {
      const code = (await c.query('SELECT fn_gen_imf_code($1) AS c', [b.country_code])).rows[0].c;
      const imf = (await c.query(
        `INSERT INTO imf(code_imf,name,type,country_code,city,capital_cents,
            bceao_agreement_no,phone_main,whatsapp,email,status)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,'pending') RETURNING id, code_imf`,
        [code, b.imf_name, b.imf_type, b.country_code, b.city, Number(b.capital_cents),
         b.bceao_agreement_no, b.whatsapp, b.phone_main, b.email]
      )).rows[0];
      const reqRow = (await c.query(
        `INSERT INTO access_request(imf_id,requester_lastname,requester_firstname,
            requester_position,admin_name)
         VALUES ($1,$2,$3,$4,$5) RETURNING id`,
        [imf.id, b.lastname, b.firstname, b.position, b.admin_name]
      )).rows[0];
      // Répercussion automatique des informations saisies sur les PARAMÈTRES de
      // l'IMF (identité visuelle + mentions légales obligatoires) : elles seront
      // reprises telles quelles sur les factures et le relevé de compte, et
      // resteront modifiables par l'admin de l'IMF une fois son accès ouvert.
      await c.query(
        `INSERT INTO imf_branding(imf_id, legal_name, legal_form, bceao_agreement_no,
             trade_register_no, tax_id,
             share_capital_cents, legal_address)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
         ON CONFLICT (imf_id) DO UPDATE SET
             legal_name         = COALESCE(imf_branding.legal_name, EXCLUDED.legal_name),
             legal_form         = COALESCE(imf_branding.legal_form, EXCLUDED.legal_form),
             bceao_agreement_no = COALESCE(imf_branding.bceao_agreement_no, EXCLUDED.bceao_agreement_no),
             trade_register_no  = COALESCE(imf_branding.trade_register_no, EXCLUDED.trade_register_no),
             tax_id             = COALESCE(imf_branding.tax_id, EXCLUDED.tax_id),
             share_capital_cents= COALESCE(imf_branding.share_capital_cents, EXCLUDED.share_capital_cents),
             legal_address      = COALESCE(imf_branding.legal_address, EXCLUDED.legal_address),
             updated_at         = now()`,
        [imf.id, b.imf_name, b.imf_type, b.bceao_agreement_no,
         String(b.rccm).trim(), String(b.ifu).trim(),
         Number(b.capital_cents) || 0,
         [b.city, b.country_code].filter(Boolean).join(', ')]);
      return { imf, requestId: reqRow.id };
    });
    res.json({ ok: true, imf_code: out.imf.code_imf, imf_id: out.imf.id, request_id: out.requestId });
  } catch (e) {
    // On nomme la vraie cause (code PostgreSQL compréhensible) au lieu de laisser
    // remonter un « server_error » muet que le formulaire traduisait par
    // « Une erreur est survenue ». Aucune donnée sensible n'est exposée.
    const pg = e && e.code ? String(e.code) : '';
    const detail = {
      '23502': 'missing_column_value',   // une colonne NOT NULL non renseignée
      '23503': 'invalid_reference',      // clé étrangère introuvable
      '23505': 'duplicate_code',         // doublon de code IMF
      '23514': 'check_violation',        // contrainte de contrôle
      '22P02': 'invalid_input_syntax',   // valeur mal typée
      '42703': 'missing_column',         // colonne absente du schéma
      '42P01': 'missing_table',          // table absente du schéma
      '42P02': 'missing_type'            // type enum absente
    }[pg];
    if (detail) {
      const diag = { error: detail };
      const msg = {
        missing_column_value: 'Une information obligatoire n’a pas pu être enregistrée. Vérifiez tous les champs du formulaire.',
        invalid_reference: 'Référence interne invalide lors de l’enregistrement. Contactez teeBo.',
        duplicate_code: 'Ce code d’IMF existe déjà. Réessayez dans un instant.',
        check_violation: 'Une valeur saisie ne respecte pas le format attendu. Vérifiez le RCCM, l’IFU et le capital.',
        invalid_input_syntax: 'Le format d’une valeur saisie est invalide. Vérifiez les numéros et le capital.',
        missing_column: 'Le serveur n’est pas à jour (colonne manquante en base). Déployez la version corrigée.',
        missing_table: 'Le serveur n’est pas à jour (table manquante en base). Déployez la version corrigée.',
        missing_type: 'Le serveur n’est pas à jour (type manquant en base). Déployez la version corrigée.'
      }[detail];
      if (msg) diag.message = msg;
      if (pg) diag.pg = pg;
      return res.status(422).json(diag);
    }
    next(e);
  }
});

// --- Étape 2 : choix de la formule -> facture proforma ---------------------
router.post('/:id/select-plan', async (req, res, next) => {
  try {
    const { plan_code, billing_cycle } = req.body || {};
    const requested = requestedModules(req.body);
    const codes = requested.length ? requested : requestedModules({ module_codes: plan_code ? [plan_code] : [] });
    if (!codes.length) return res.status(422).json({ error: 'no_module_selected',
      message: 'Choisissez au moins un module pour établir la proforma.' });
    const billing = BILLING_CYCLES.includes(billing_cycle) ? billing_cycle : 'mensuel';
    // Tarifs lus en BASE (source de vérité), jamais envoyés par le navigateur.
    let modRows = [];
    try {
      ({ rows: modRows } = await q(
        `SELECT module_key AS code, module_name AS label,
                monthly_subscription_price::bigint AS price_cents
           FROM saas_modules_pricing WHERE module_key = ANY($1)`, [codes]));
    } catch (e) {
      // Table absente (migration partielle) : on continue avec le catalogue
      // du code, sinon la proforma etait impossible a generer.
      console.error('[select-plan] table de tarifs indisponible :', e && (e.code || e.message));
      modRows = [];
    }
    if (!modRows.length) {
      // Les modules demandes sont connus du catalogue : on les facture au
      // tarif officiel du code plutot que d'echouer.
      const connus = codes.filter((c) => catalogModule(c));
      if (!connus.length) return res.status(404).json({ error: 'module_not_found',
        message: 'Ces modules ne sont pas reconnus. Choisissez-les dans la liste affichee.' });
      modRows = connus.map((c) => {
        const m = catalogModule(c);
        return { code: c, label: m.label, price_cents: m.monthlyCents };
      });
    }
    const modules = normalizeModules(modRows.map((m) => ({
      key: m.code, label: m.label, monthlyCents: Number(m.price_cents) })));
    const pr = computePricing(modules, billing, { fullPack: true });
    const fullPack = pr.fullPack === true;
    const planLabel = modules.map((m) => m.label).join(' + ');
    const proformaNo = 'PRO-' + new Date().getFullYear() + '-' +
      Math.floor(100000 + Math.random() * 900000);
    const subCents = pr.modulesGrossCents;
    const { rows } = await q(
      `UPDATE access_request SET plan_code=$1, billing_cycle=$2, licence_cents=$3,
          subscription_cents=$4, discount_cents=$5, proforma_no=$6,
          proforma_amount_cents=$7, proforma_validated=false,
          module_codes=$9::text[], module_count=cardinality($9::text[]),
          full_pack=$10, pack_discount_cents=$11, annual_discount_cents=$12
       WHERE id=$8 RETURNING *`,
      [fullPack ? 'PACK_COMPLET' : modules.map((m) => m.key).join('+'),
       pr.billing, pr.licenceCents, subCents, pr.discountCents,
       proformaNo, pr.totalCents, req.params.id,
       modules.map((m) => m.key), fullPack, pr.packDiscountCents, pr.annualDiscountCents]
    );
    if (!rows.length) return res.status(404).json({ error: 'request_not_found' });
    const r = rows[0];
    const imf = (await q('SELECT * FROM imf WHERE id=$1', [r.imf_id])).rows[0];
    res.json({ ok: true, proforma: {
      no: proformaNo,
      modules: modules.map((m) => ({ code: m.key, label: m.label, monthly_cents: m.monthlyCents })),
      module_codes: modules.map((m) => m.key),
      module_count: modules.length,
      full_pack: fullPack,
      label: planLabel,
      billing_cycle: pr.billing, period_label: pr.periodLabel,
      licence_cents: pr.licenceCents,
      subscription_cents: subCents,
      gross_subscription_cents: pr.modulesGrossCents,
      annual_discount_cents: pr.annualDiscountCents,
      pack_discount_cents: pr.packDiscountCents,
      savings_cents: pr.discountCents,
      discount_cents: pr.discountCents,
      subtotal_cents: pr.subtotalCents,
      amount_cents: pr.totalCents,
      monthly_cents: pr.monthlyEquivalentCents,
      trial_days: 30,
      imf_name: imf ? imf.name : null,
      date: new Date().toISOString(),
      url: `/api/v1/requests/${r.id}/proforma.pdf`
    }});
  } catch (e) { next(e); }
});

// --- Facture PROFORMA imprimable (PDF via HTML) ----------------------------
// Numéro de proforma : PRO-AAAA-XXXXXX. Visible par le prospect au moment du
// choix des modules, puis validée pour transmission à teebo.
router.get('/:id/proforma.pdf', async (req, res, next) => {
  try {
    const r = (await q('SELECT * FROM access_request WHERE id=$1', [req.params.id])).rows[0];
    if (!r || !r.proforma_no) return res.status(404).json({ error: 'proforma_not_found' });
    const imf = (await q('SELECT * FROM imf WHERE id=$1', [r.imf_id])).rows[0];
    const header = await getBranding(r.imf_id);
    // Reconstitution du détail : licence + UNE LIGNE PAR MODULE souscrit
    // (+ remises réellement consenties). Une ancienne demande sans liste de
    // modules (plan_code historique) est présentée comme un module unique.
    // Coercition NUMÉRIQUE : node-postgres renvoie les BIGINT en CHAÎNES, une
    // addition sans Number() concaténerait les montants.
    const licenceCents = Math.round(Number(r.licence_cents != null ? r.licence_cents : LICENCE_CENTS)) || 0;
    const subscriptionCents = Math.round(Number(r.subscription_cents || 0)) || 0;
    const discountCents = Math.round(Number(r.discount_cents || 0)) || 0;
    const subtotalCents = licenceCents + subscriptionCents;
    const totalCents = r.proforma_amount_cents != null
      ? Math.round(Number(r.proforma_amount_cents)) : (subtotalCents - discountCents);
    const codes = (Array.isArray(r.module_codes) && r.module_codes.length)
      ? r.module_codes : (r.plan_code ? [r.plan_code] : []);
    let modules = [];
    if (codes.length) {
      const { rows: modRows } = await q(
        `SELECT module_key AS code, module_name AS label,
                monthly_subscription_price::bigint AS price_cents
           FROM saas_modules_pricing WHERE module_key = ANY($1)`, [codes]);
      modules = normalizeModules(modRows.map((m) => ({
        key: m.code, label: m.label, monthlyCents: Number(m.price_cents) })));
    }
    const billing = r.billing_cycle === 'annuel' ? 'annuel' : 'mensuel';
    // Le montant stocké fait foi ; la reconstruction ne sert qu'à détailler les
    // lignes. Si la liste des modules est inconnue (très ancienne demande) on
    // retombe sur une ligne d'abonnement globale, jamais une pièce vide.
    const lines = modules.length
      ? buildInvoiceLines({ modules, billing, licenceCents, modulesGrossCents: subscriptionCents })
      : [{ label: 'Abonnement modules teeBo — ' + (billing === 'annuel' ? '12 mois (annuel)' : '1 mois (mensuel)'),
          amountCents: subscriptionCents }];
    if (!modules.length) lines.unshift({ label: 'Licence teeBo — activation (frais unique)', amountCents: licenceCents });
    const html = renderInvoice({
      header,
      kind: 'proforma',
      invoiceNo: r.proforma_no,
      issuedAt: r.created_at || new Date(),
      periodLabel: billing === 'annuel' ? '12 mois (annuel)' : '1 mois (mensuel)',
      lines,
      subtotalCents,
      discountCents,
      totalCents,
      currency: 'XOF',
      status: r.proforma_validated ? 'emise' : null,
      clientName: imf ? imf.name : (header.legal_name || 'IMF'),
      clientCode: header.imf.email || '',
      notes: TRIAL_BILLING_NOTE
    });
    setDocumentCsp(res);
    res.type('html').send(html);
  } catch (e) { next(e); }
});

// --- Facture DÉFINITIVE publique (tokenisée) -------------------------------
// Permet à l'IMF d'ouvrir le lien de facture reçu par WhatsApp / e-mail, sans
// être connecté à la console teebo. L'accès est protégé par un jeton HMAC
// (?t=...) : seul le détenteur du lien transmis par teebo peut l'ouvrir.
router.get('/invoices/:id.pdf', async (req, res, next) => {
  try {
    if (!verifyDocToken(req.params.id, req.query.t))
      return res.status(403).json({ error: 'invalid_token' });
    const inv = (await q('SELECT * FROM invoice WHERE id=$1', [req.params.id])).rows[0];
    if (!inv) return res.status(404).json({ error: 'invoice_not_found' });
    const header = await getBranding(inv.imf_id);
    const imf = (await q('SELECT name, email FROM imf WHERE id=$1', [inv.imf_id])).rows[0] || {};
    const ar = inv.request_id
      ? (await q('SELECT billing_cycle, licence_cents, subscription_cents, module_codes FROM access_request WHERE id=$1', [inv.request_id])).rows[0]
      : null;
    let lines = null;
    if (ar && (ar.licence_cents != null || ar.subscription_cents != null || (ar.module_codes || []).length)) {
      const billing = ar.billing_cycle === 'annuel' ? 'annuel' : 'mensuel';
      const licenceCents = Math.round(Number(ar.licence_cents || 0)) || 0;
      const subscriptionCents = Math.round(Number(ar.subscription_cents || 0)) || 0;
      let modules = [];
      if ((ar.module_codes || []).length) {
        const { rows: modRows } = await q(
          `SELECT module_key AS code, module_name AS label,
                  monthly_subscription_price::bigint AS price_cents
             FROM saas_modules_pricing WHERE module_key = ANY($1)`, [ar.module_codes]);
        modules = normalizeModules(modRows.map((m) => ({
          key: m.code, label: m.label, monthlyCents: Number(m.price_cents) })));
      }
      lines = modules.length
        ? buildInvoiceLines({ modules, billing, licenceCents, modulesGrossCents: subscriptionCents })
        : [{ label: 'Licence teeBo — activation (frais unique)', amountCents: licenceCents },
           { label: 'Abonnement modules teeBo — ' + (billing === 'annuel' ? '12 mois (annuel)' : '1 mois (mensuel)'),
             amountCents: subscriptionCents }];
    }
    const html = renderInvoice({
      header, kind: 'definitive', invoiceNo: inv.invoice_no,
      issuedAt: inv.issued_at, dueAt: inv.due_at,
      periodLabel: inv.period_label || (ar && ar.billing_cycle === 'annuel' ? '12 mois (annuel)' : (ar ? '1 mois (mensuel)' : null)),
      plan: inv.plan_label || inv.plan_code, lines,
      subtotalCents: inv.subtotal_cents, discountCents: inv.discount_cents,
      vatRateBp: inv.vat_rate_bp, vatCents: inv.vat_cents,
      totalCents: inv.total_cents, currency: inv.currency,
      status: inv.status, amountPaidCents: inv.amount_paid_cents,
      clientName: imf.name || header.legal_name, clientCode: imf.email || '',
      notes: inv.notes
    });
    setDocumentCsp(res);
    res.type('html').send(html);
  } catch (e) { next(e); }
});

// --- Étape 3 : validation de la facture proforma ---------------------------
router.post('/:id/validate-proforma', async (req, res, next) => {
  try {
    const { rows } = await q(
      `UPDATE access_request SET proforma_validated=true, proforma_validated_at=now()
       WHERE id=$1 AND proforma_no IS NOT NULL RETURNING *`, [req.params.id]
    );
    if (!rows.length) return res.status(409).json({ error: 'no_proforma' });
    const r = rows[0];
    // teebo est notifié de la nouvelle demande à approuver.
    await notifyEmail(TEEBO_EMAIL, 'Nouvelle demande IMF à approuver',
      `Demande ${r.id} — proforma ${r.proforma_no} validée.`);
    await notifyWhatsApp(TEEBO_WHATSAPP, `teebo: nouvelle demande IMF validée (proforma ${r.proforma_no}).`);
    res.json({ ok: true, message: 'Demande transmise à teebo pour approbation.' });
  } catch (e) { next(e); }
});

export default router;
